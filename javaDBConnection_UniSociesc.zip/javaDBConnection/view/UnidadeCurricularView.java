package view;

import java.util.List;

import model.UnidadeCurricular;

public class UnidadeCurricularView {
    public static void listarUCs(List<UnidadeCurricular> ucs) {
        for( UnidadeCurricular uc : ucs) {
            System.out.println(uc.getId()+" -> "+uc.getNome());
        }

    }
}
