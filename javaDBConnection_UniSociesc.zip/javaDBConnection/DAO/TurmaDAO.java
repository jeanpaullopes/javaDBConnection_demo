package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Turma;
import repository.UnidadeCurricularRepository;

public class TurmaDAO {
    

    public static List<Turma> getTurmas() {
        List<Turma> retorno = new ArrayList<>();
        Connection conn = DBConnection.getInstance().getConnection();

        try {
            
            PreparedStatement ps = conn.prepareStatement("SELECT t.* FROM mydb.turmas t");
            ResultSet resultSet = ps.executeQuery();
            //resultSet.first();
            while (resultSet.next()) {
                Turma tmp = new Turma(resultSet.getInt("id"), 
                                        resultSet.getInt("semestre"),
                                        resultSet.getInt("ano"),
                                        resultSet.getString("tipo"),
                                        UnidadeCurricularRepository.getUCById(resultSet.getInt("unidades_curriculares_id")));

                                       

                retorno.add(tmp);
                
            }

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return retorno;
    }
    public static Turma salvarTurma(Turma turma) {
        
        Connection conn = DBConnection.getInstance().getConnection();
        try {
            PreparedStatement ps = conn.prepareStatement("insert into turmas (semestre, ano, tipo, unidades_curriculares_id) "+
                                                        "values (?, ?, ?, ?)");
            ps.setInt(1, turma.getSemestre());
            ps.setInt(2, turma.getAno());
            ps.setString(3, turma.getTipoBD());
            ps.setInt(4, turma.getUc().getId());
            //ps.setInt(2, null);
            ps.executeUpdate();

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }
    
}
