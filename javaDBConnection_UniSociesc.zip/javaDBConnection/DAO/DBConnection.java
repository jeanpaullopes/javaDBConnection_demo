package DAO;
import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
    private static DBConnection instance = null;
    private Connection conn = null;
    private String url = "jdbc:mysql://192.168.0.237:3306/";
    private String dbName = "mydb";
    private String driver = "com.mysql.jdbc.Driver";
    private String userName = "root";
    private String password = "SuperTsa";
    private DriverManager driverManager = null;

    private DBConnection() {
        try {
            //Class.forName(driver);
            conn = DriverManager.getConnection(url + dbName, userName, password);
        } catch (Exception e) {
            
            e.printStackTrace();
        }
        //System.out.println(conn);
        
    }  
    public static DBConnection getInstance() {
        if (instance == null) {
            instance = new DBConnection();
        }
        return instance;
    } 

    public Connection getConnection() {
        return conn;
    }
}
