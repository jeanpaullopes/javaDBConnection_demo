package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.UnidadeCurricular;

public class UnidadeCurricularDAO {
    public static List<UnidadeCurricular> getUnidadesCurriculares() {
        List<UnidadeCurricular> retorno = new ArrayList<>();
        Connection conn = DBConnection.getInstance().getConnection();

        try {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM unidades_curriculares");
            ResultSet resultSet = ps.executeQuery();
            //resultSet.first();
            while (resultSet.next()) {
                UnidadeCurricular tmp = new UnidadeCurricular(resultSet.getInt("id"), 
                                            resultSet.getString("nome"));
                retorno.add(tmp);
                
            }

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return retorno;
    }
    
    
}
