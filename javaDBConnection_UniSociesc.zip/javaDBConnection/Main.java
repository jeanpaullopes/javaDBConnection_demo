
import controller.AppController;

public class Main {
    public static void main(String[] args) {
        AppController controller = new AppController();
        controller.iniciar();
    }
}