package controller;
import java.util.ArrayList;
import java.util.List;

import DAO.TurmaDAO;
import DAO.UnidadeCurricularDAO;
import model.Turma;
import model.UnidadeCurricular;
import repository.UnidadeCurricularRepository;
import view.AppView;
import view.TurmaView;
import view.UnidadeCurricularView;

public class AppController {

    private List<Turma> turmas;
    
    //private Turma[] turmas2;

    public AppController() {

        UnidadeCurricularRepository.setup();
        turmas = TurmaDAO.getTurmas();

        //Turma t1 = new Turma(0, "asdasdasd", 0, 0);
        //turmas.add(t1);
        //Turma t2 = new Turma(10, "asdasdasdsdfsdfsdfsd", 0, 0);
        //turmas.add(t2);
        //turmas.indexOf(t2);
    }
    public void iniciar() {
        int op = -1;
        do{
            op = AppView.menuInicial();
            switch (op) {
                case 1: TurmaView.listarTurmas(turmas); break;
                case 2: UnidadeCurricularView.listarUCs(UnidadeCurricularRepository.getUnidadesCurriculares()); break;
                case 4: criarTurmaEIncluir(); break;
            }
        } while (op > 0);
        
    }
    public void criarTurmaEIncluir() {
        Turma t = new Turma(0, 2, 2023, "D", UnidadeCurricularRepository.getUCById(3));

        TurmaDAO.salvarTurma(t);
        //turmas.add(t);
        // com a gambiarra, não façam isto em casa
        turmas = TurmaDAO.getTurmas();

    }
    
}
