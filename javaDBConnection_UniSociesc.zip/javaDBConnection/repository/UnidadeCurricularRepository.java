package repository;

import java.util.List;

import DAO.UnidadeCurricularDAO;
import model.UnidadeCurricular;

public class UnidadeCurricularRepository {
    private static List<UnidadeCurricular> unidadesCurriculares;
    
    public static void setup() {
        unidadesCurriculares = UnidadeCurricularDAO.getUnidadesCurriculares();
    }
    public static List<UnidadeCurricular> getUnidadesCurriculares() {
        return unidadesCurriculares;
    }

    public static UnidadeCurricular getUCById(int id) {
        for(UnidadeCurricular uc : unidadesCurriculares) {
            if(uc.getId() == id) {
                return uc;
            }
        }
        return null;
    }

    
}
