package model;

public class Turma {
    private int id;
    private int semestre;
    private int ano;
    private String tipo;
    private UnidadeCurricular uc;
    //private int idUC;
    //private String nomeUC;

    public Turma() {
        this.id = -1;
        this.semestre = 1;
        this.ano = 2024;
        this.tipo = "P";
        //this.idUC = -1;
        //this.nomeUC = ""; 
    }
    ;   
    public Turma(int id, int semestre, int ano, String tipo, UnidadeCurricular uc) { //int idUC, String nomeUC) {
        this.id = id;
        this.semestre = semestre;
        this.ano = ano;
        this.tipo = tipo;
        this.uc = uc;
        //this.idUC = idUC;
        //this.nomeUC = nomeUC;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }



    public int getSemestre() {
        return semestre;
    }



    public void setSemestre(int semestre) {
        this.semestre = semestre;
    }



    public int getAno() {
        return ano;
    }



    public void setAno(int ano) {
        this.ano = ano;
    }



    public String getTipo() {
        if (tipo.equals("P"))
        return "Presencial";
        else return "Online";
    }
    public String getTipoBD() {
        return tipo;
    }



    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    public UnidadeCurricular getUc() {
        return uc;
    }
    public void setUc(UnidadeCurricular uc) {
        this.uc = uc;
    }


/* 
    public int getIdUC() {
        return idUC;
    }



    public void setIdUC(int idUC) {
        this.idUC = idUC;
    }



    public String getNomeUC() {
        return nomeUC;
    }



    public void setNomeUC(String nomeUC) {
        this.nomeUC = nomeUC;
    }
  */  

    
    
}
